#include <SDL.h>
#include "WindowHandler.h"
#include "type.h"
#include "cursor.h"

int quit = 0;
int main(int argc, char *argv[]) {
    SDL_Event event;
    WindowHandler Window = CreateSDLWindow();
    if (argc > 1)
    {
        Lines lines = OpenFile(argv[1]);
        SDL_Color fg = {255, 255, 255};
        while (!quit) {
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    quit = 1;
                }
            }

            SDL_SetRenderDrawColor(Window.renderer, 0, 0, 0, 0);
            SDL_RenderClear(Window.renderer);

            int y = 0;
            for (int i = 0; i < lines.size; i++) {
                char* line = lines.lines[i].chars;
                SDL_Surface* lineSurface = TTF_RenderText_Solid(Window.font, line, fg);
                if (lineSurface == NULL) {
                    printf("Couldn't render text: %s\n", TTF_GetError());
                    exit(1);
                }
                SDL_Texture* lineTexture = SDL_CreateTextureFromSurface(Window.renderer, lineSurface);
                if (lineTexture == NULL) {
                    printf("Couldn't create texture from surface: %s\n", SDL_GetError());
                    exit(1);
                }
                SDL_Rect destRect;
                destRect.x = 0;
                destRect.y = y;
                destRect.w = lineSurface->w;
                destRect.h = lineSurface->h;
                SDL_RenderCopy(Window.renderer, lineTexture, NULL, &destRect);
                SDL_FreeSurface(lineSurface);
                SDL_DestroyTexture(lineTexture);
                y += lineSurface->h;
            }

            SDL_RenderPresent(Window.renderer);
        }
        SDL_FreeSurface(Window.surface);
        SDL_DestroyTexture(Window.texture);
    }
    else
    {
        Lines lines = CreateBlankPage();
        //Lines lines = OpenFile("E:\\nhf\\cmake-build-debug\\test.txt");
        // create a blank page
        SDL_Color fg = {255, 255, 255};
        while (!quit)
        {
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    quit = 1;
                }
            }
            SDL_SetRenderDrawColor(Window.renderer, 0, 0, 0, 0);
            SDL_RenderClear(Window.renderer);
        }
    }

    SDL_Quit();

    return 0;
}
